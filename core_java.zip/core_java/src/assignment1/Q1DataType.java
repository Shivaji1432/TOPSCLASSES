package assignment1;

import java.util.*;

public class Q1DataType {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a,b;
		float a1=10;
		short b1=20;
		long  l=12545255165l;
		a=sc.nextInt();
		b=sc.nextInt();
		int c=a+b;
		System.out.println(c);
		System.out.println(b1+b);
        System.out.println(a1+a);
        System.out.println(l+a+b);
	}

}
