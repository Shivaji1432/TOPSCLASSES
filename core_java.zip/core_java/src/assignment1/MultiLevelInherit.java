package assignment1;
class Accounts{
	void display() {
		System.out.println("bank account ...");
	}
}
class SavingAc extends Accounts{
	void detail() {
		System.out.println("saving account info");
	}
}
class Current extends SavingAc{
	void detail() {
		System.out.println("saving account info");
	}
}
public class MultiLevelInherit {
public static void main(String[] args) {
	Current c=new Current();
	c.detail();
	c.display();
	SavingAc s=new SavingAc();
	s.detail();
	s.display();
}
}
