package assignment1;

public class StringPalindrome {
public static void main(String[] args) {
	String str="pop";
	char ch1 = 0,ch2 = 0;
	char ch[]=str.toCharArray();
	for (int i = 0; i < ch.length; i++) {
		ch1=ch[i];
		System.out.print(ch1);
	}System.out.println();
	for (int i =ch.length-1;i>=0; i--) {
		 ch2=ch[i];
		System.out.print(ch2);
	}System.out.println();
	if(ch1==ch2) {
		System.out.println("palindrom");
	}else {
		System.out.println("not palindrom");
	}
}
}
