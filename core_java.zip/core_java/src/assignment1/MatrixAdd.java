package assignment1;

public class MatrixAdd {
public static void main(String[] args) {
	int a[][]= {{12,13,10},{12,10,10},{14,15,25}};
	int b[][]= {{12,13},{12,10},{14,15}};
	
}
}
