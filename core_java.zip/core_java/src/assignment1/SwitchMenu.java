package assignment1;

import java.util.Scanner;

public class SwitchMenu {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter your orders");
	String s=sc.next();
	switch(s) {
	case "coffee" :
		System.out.println("Here is your coffee sir...");
		break;
	case "tea" :
		System.out.println("Here is your tea sir...");
		break;
	case "juice" :
		System.out.println("Here is your juice sir...");
	}
}
}
