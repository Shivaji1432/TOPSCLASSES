package assignment1;

public class HelloWld {
public static void main(String[] args) {
	System.out.println("hello world");
}
}
