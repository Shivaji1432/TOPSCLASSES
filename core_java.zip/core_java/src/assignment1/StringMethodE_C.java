package assignment1;

public class StringMethodE_C {
public static void main(String[] args) {
	String s="shiv";
	String s1="shankar";
	String s2="shiv";
	System.out.println(s.equals(s2));
	System.out.println(s.equals(s1));
	System.out.println(s.compareTo(s2));
	System.out.println(s1.compareTo(s));
}
}
