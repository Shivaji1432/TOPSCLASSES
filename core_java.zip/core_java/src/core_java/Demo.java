package core_java;

public class Demo {

	public static void main(String[] args) {
		System.out.println("hello java");
		}

}
