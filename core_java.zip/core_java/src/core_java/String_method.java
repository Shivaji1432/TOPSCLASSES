package core_java;

public class String_method {
public static void main(String[] args) {
	
}
}
