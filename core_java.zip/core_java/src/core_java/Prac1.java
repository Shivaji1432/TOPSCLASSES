package core_java;

public class Prac1 {
public static void main(String[] args) {
//        int n=5;
//	for(int i=1;i<=n;i++) {
//		for(int j=1;j<=i;j++) {
//			System.out.print(j);
//		}System.out.println("");
//	}
//	for(int i=1;i<=n;i++) {
//		for(int j=1;j<=i;j++) {
//			System.out.print((i+j)%2);
//		}System.out.println("");
//	}
//	
//	
//	int k=1;
//	for(int i=1;i<=n;i++) {
//		for(int j=1;j<=i;j++) {
//			System.out.print(k+" ");
//			k++;
//		}System.out.println("");
//	}
//         k=65;
//        for(int i=65;i<=69;i++) {
//    		for(int j=65;j<=i;j++) {
//    			//j=(char)j;
//    			System.out.print((char)k);
//    			k++;
//    		}System.out.println("");
//    	}
	int n=5;
	int sp=n-1;
	int st=1;
	int mid=(n/2)+1;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=sp;j++) {
			System.out.print(" ");
		}
		for(int j=1;j<=st;j++) {
			System.out.print("* ");
		}
		if(i<mid) {
		st++;
		sp--;
		}else {
			st--;
			sp++;
		}
		System.out.println("");
	}
}
}
