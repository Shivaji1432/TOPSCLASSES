package core_java;

public class Operator_arthmetric {

	public static void main(String[] args) {
		int a=10;
		float b=15;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		System.out.println("sum of a+b= "+a+b);
		System.out.println(a-b+" sub of a-b");
		System.out.println(a*b+" multiple of ab");
		System.out.println(a/b+" divsion of ab");
		System.out.println(a%b+" module of ab");
	}

}
